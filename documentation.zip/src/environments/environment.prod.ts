export const environment = {
  production: true,
  // apiUrl: 'http://localhost:3000/api'
  apiUrl: 'http://18.219.3.216:3000/api'
};
